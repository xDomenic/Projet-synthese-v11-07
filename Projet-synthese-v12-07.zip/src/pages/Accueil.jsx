import React from "react";
import Gallerie from "../components/accueil/Gallerie";
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";
import BandeAccueil from "../components/accueil/BandeAccueil";
import TopListeFilms from "../components/accueil/TopListeFilms";
import Bande from "../components/accueil/Bande";
import BoutonCategories from "../components/categories/BoutonCategories";
import { useState } from "react";

const Accueil = () => {
  const [selected, setSelected] = useState([]);

  return (
    <>
      <Navigation />
      <main>
        <Gallerie />
        <TopListeFilms selected={selected} />
        <BoutonCategories selected={selected} setSelected={setSelected} />
        <Bande />
        <BandeAccueil />
      </main>
      <Footer />
    </>
  );
};
export default Accueil;
