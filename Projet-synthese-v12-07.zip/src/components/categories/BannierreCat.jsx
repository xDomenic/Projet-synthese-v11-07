import React from "react";

const BanniereCat = () => {
  return (
    <section
      className="recherche-services-area services-bg-two"
      style={{ backgroundImage: 'url("../img/banner/banner_bg01.jpg")' }}
    ></section>
  );
};
export default BanniereCat;
