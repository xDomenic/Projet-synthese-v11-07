import React, { useEffect } from "react";
import $ from "jquery";
import "magnific-popup";

const FilmsDetails = () => {
  useEffect(() => {
    $(".popup-video").magnificPopup({
      type: "iframe",
    });
  }, []);

  return (
    <section
      className="movie-details-area"
      style={{ backgroundImage: 'url("../img/bg/movie_details_bg.jpg")' }}
    >
      <div className="container">
        <div className="row align-items-center position-relative ml-5">
          <div className="col-xl-4 col-lg-8">
            <div className="movie-details-img">
              <img src="img/poster/movie_details_img-1.jpg" alt="" />
            </div>
          </div>
          <div className="col-xl-6 col-lg-8 ml-5">
            <div className="movie-details-content">
              <h5>MBDL vous souhaite Bon cinéma</h5>
              <h2>
                Au-delà de nos<span> rêves</span>
              </h2>
              <div className="banner-meta">
                <ul>
                  <li className="quality">
                    <span>Pg-13 </span>
                    <span>hd</span>
                  </li>
                  <li className="category">
                    <a href="/#">Drame,</a>
                    <a href="/#">Fantastique</a>
                    <a href="/#">Romance</a>
                  </li>
                  <li className="release-time">
                    <span>
                      <i className="far fa-calendar-alt" /> 1998
                    </span>
                    <span>
                      <i className="far fa-clock" /> 1h 46m
                    </span>
                  </li>
                </ul>
              </div>
              <p>Après la vie, il y a plus. La fin n'est que le début.</p>
              <p>
                Chris et Annie forment un couple indissolublement lié capable de
                surmonter les plus rudes épreuves. Après quelques années d'une
                vie idyllique, leurs enfants, Ian et Marie, leur sont
                brutalement arrachés dans un accident de voiture. Si Chris cache
                sa douleur, Annie s'éloigne inéxorablement de lui, se mure dans
                sa solitude et se réfugie dans la peinture. Quand Chris est à
                son tour victime d'une tragique collision, il meurt mais ne
                disparait pas. Il connait une autre vie a travers les peintures
                d'Annie qui se mettent à s'animer et il comprend, ainsi, l'âme
                de sa femme.
              </p>
              <div className="movie-details-prime">
                <ul>
                  <li className="share">
                    <a href="/#">
                      <i className="fas fa-share-alt" /> Partager
                    </a>
                  </li>
                  <li className="streaming">
                    <h6>MBDL</h6>
                    <span>Chaînes de diffusion en continu</span>
                  </li>
                  <li className="watch">
                    <a
                      href="https://www.themoviedb.org/video/play?key=0jIGkBm7IGw"
                      className="btn popup-video"
                    >
                      <i className="fas fa-play" /> Voir Maintenant
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default FilmsDetails;
