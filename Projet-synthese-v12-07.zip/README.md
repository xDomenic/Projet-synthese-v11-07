Clé API TMBD

API_URL="https://api.themoviedb.org/3/movie/popular?api_key=b9590de348b1de72934da4fdd68b6f97"
API_IMG="https://image.tmdb.org/t/p/w500/"
API_TRENDING="https://api.themoviedb.org/3/trending/all/day?api_key=b9590de348b1de72934da4fdd68b6f97"
API_SEARCH="https://api.themoviedb.org/3/search/movie?api_key=b9590de348b1de72934da4fdd68b6f97&language=fr-FR&query"
API_SEARCH PEOPLE="https://api.themoviedb.org/3/search/person?api_key=b9590de348b1de72934da4fdd68b6f97&language=fr-FR&page=1&include_adult=false"
API_MOVIE/TOP/RATED="https://api.themoviedb.org/3/movie/top_rated?api_key=b9590de348b1de72934da4fdd68b6f97&language=fr-FR&page=1"
API_MOVIE/UPCOMING="https://api.themoviedb.org/3/movie/upcoming?api_key=b9590de348b1de72934da4fdd68b6f97&language=en-US&page=1"
API_GET/MOVIE/{movie_id}="https://api.themoviedb.org/3/movie/{movie_id}?api_key=b9590de348b1de72934da4fdd68b6f97&language=fr-FR"
API_GET/movie/{movie_id}/release_dates="https://api.themoviedb.org/3/movie/{movie_id}/release_dates?api_key=b9590de348b1de72934da4fdd68b6f97"
API_VIDEO="https://api.themoviedb.org/3/movie/{movie_id}/videos?api_key=b9590de348b1de72934da4fdd68b6f97&language=fr-FR"

saison/serie/tv="https://api.themoviedb.org/3/tv/{tv_id}/season/{season_number}?api_key=b9590de348b1de72934da4fdd68b6f97&language=fr-FR"
/pisode/tv="
https://api.themoviedb.org/3/tv/{tv_id}/season/{season_number}/episode/{episode_number}?api_key=b9590de348b1de72934da4fdd68b6f97&language=fr-FR"
API_ACTEUR="https://api.themoviedb.org/3/person/{person_id}?api_key=b9590de348b1de72934da4fdd68b6f97&language=fr-FR"

Clé d'API (v3 auth) de Lyne
https://api.themoviedb.org/3
b9590de348b1de72934da4fdd68b6f97
https://www.youtube.com/watch?v=qQT_vadvUmM

Bressy, Benjamin
4e6fa142223438b28dd2dcf861f95d6e

Khtib, Mhamed
Your API key is: f96f47f3f32e453ea80563f44634d185

Pasquarelli, Domenico
11c5603767c58ad4b5e0b33c3d09fc60
